<?php

    define("APP",dirname(__FILE__));
    define("URL", "http://localhost/AppGarcon/");
    define("APP_NAME", "Learn about MVC");
    define("EMPRESA", "pizzaria");