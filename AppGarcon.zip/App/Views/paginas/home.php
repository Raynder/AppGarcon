<div class="conteudo">

    <div>
        <h1>HOola</h1>
        <span class="tente">tantskdl</span>
    </div>
</div>