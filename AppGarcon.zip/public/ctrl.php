<?php
session_start();
include "./../App/config.php";
include "./../App/autoload.php";
//defini os paths para as classes do sistema e as classes gerais

$path["conexao"] = "painel/classes/";
$path["site"] = 'http://localhost/AppGarcon/';


?>